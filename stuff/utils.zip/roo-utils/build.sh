sed -i s/document\.createElement\(\"udesly-banner\"\)// theme/*.html
npm run build
